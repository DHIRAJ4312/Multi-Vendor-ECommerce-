# Multi-Vendor E-Commerce — Starter Backend

**How to run**
1. Create MySQL database `mv_ecommerce` and user (see main guide).
2. Edit `src/main/resources/application.properties` if needed.
3. `mvn spring-boot:run`

**Test quickly**
- `POST /api/categories` with `{ "name": "Electronics", "slug": "electronics" }`
- `GET /api/categories`
- `POST /api/products` with `{ "name": "Phone X", "categoryId": 1, "price": 49999, "stock": 10 }`
- `GET /api/products`

Then add JWT auth, vendor flows, orders, reviews, and payments following the guide.
