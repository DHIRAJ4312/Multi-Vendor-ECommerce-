package com.example.mv.user;

public enum Role { CUSTOMER, VENDOR, ADMIN }
