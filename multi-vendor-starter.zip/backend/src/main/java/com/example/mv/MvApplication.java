package com.example.mv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvApplication {
  public static void main(String[] args) {
    SpringApplication.run(MvApplication.class, args);
  }
}
