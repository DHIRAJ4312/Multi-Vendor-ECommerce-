export const environment = {
  api: 'http://localhost:8080/api'
};